.. include:: replace.txt

Bridge NetDevice
----------------

*Placeholder chapter*

Some examples of the use of Bridge NetDevice can be found in ``examples/csma/``
directory. 
