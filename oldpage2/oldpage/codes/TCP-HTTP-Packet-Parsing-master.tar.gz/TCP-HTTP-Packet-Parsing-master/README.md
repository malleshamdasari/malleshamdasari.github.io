# TCP-HTTP-Packet-Parsing
Parsing TCP and HTTP packets in C language using libpcap library

********************************************************************************
*************************** FCN Homework2 README ***************************
********************************************************************************

The goal of this assignment is to get the in-depth knowledge of Http and TCP pac
ket parsing manually.

Notes:
======

1. This folder contains 4 sub folders each enclosing correspoding section of ass
ignment II.

2. Please find the respective folders for corresponding code or documentation.

3. The code compilation and installation instructions are given in each sub fold
er corresponding to each part.

4. C language is used to implement the functionality along with libpcap library.

5. Kindly follow the instructions/assumptions on how each decision is taken, in 
part of the assignment in the README or corresponding document.

6. For all the parsing, the L2/L3 packets are assumed to be ethernet packets.
